var icon = "https://onofficiel.github.io/w96-repos/dist/border/16x16.png";

class WebBorder extends w96.WApplication {
	constructor() {
		super();
	}
	
	async main(argv) {
		super.main(argv);
		
		// Create a simple window
		const wnd = this.createWindow({
			title: "Border",
			body: `
            <iframe src="https://onofficiel.github.io/border/#${argv ? encodeURI(argv) : ''}" width="100%" height="100%" frameBorder="0"></iframe>
            `,
			initialHeight: 480,
			initialWidth: 640,
			taskbar: true,
			icon: icon
		}, true);
		
		wnd.show();
	}
}

w96.app.register({
    command: "web-border",
    type: "gui",
    cls: WebBorder,
    meta: {
        icon: icon,
        friendlyName: "Web Border"
    }
})

w96.shell.mkShortcut("c:/system/programs/Accessories/Border.link", icon, "web-border");